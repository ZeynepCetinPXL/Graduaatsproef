<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('motivatiebriefs', function (Blueprint $table) {
            $table->id();
            $table->text('status')->nullable();
            $table->longText('motivatiebrief');
            $table->integer('gebruiker_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('motivatiebriefs');
    }
};
