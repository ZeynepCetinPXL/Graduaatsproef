<?php

namespace Database\Seeders;

use App\Models\Test;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;


class TestenSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
            Test::create([
                'naam' => 'Designer',
                'samenvatting' => 'Dit is een test voor de positie van UI designer',
            ]);

            Test::create([
                'naam' => 'Web development',
                'samenvatting' => 'Dit is een test voor een fornt end developer',
            ]);
    }
}
