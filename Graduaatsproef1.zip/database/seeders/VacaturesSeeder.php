<?php

namespace Database\Seeders;

use App\Models\Vacature;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;


class VacaturesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        //$testId = DB::table('testen')->value('id');

            Vacature::create([
                'naam' => 'Designer',
                'samenvatting' => 'UI designer',
                //'test_id' => Test::first()->id,
                //'test_id' => $testId,
                'test_id' => 01,
                'status' => 'inactief',
                'aantal' => 4,
            ]);
            Vacature::create([
                'naam' => 'Web development',
                'samenvatting' => 'Dit is een positie voor een fornt end developer',
                'test_id' => 02,
                'status' => 'actief',
                'aantal' => 2,
            ]);
    }
}
