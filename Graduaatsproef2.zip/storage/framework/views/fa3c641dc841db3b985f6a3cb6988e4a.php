<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Test</title>
</head>
<body>
    <div class="testNav">
        <div>
            <img src="<?php echo e(URL::asset('assets/logo.svg')); ?>" width="100px">
        </div>
        <div>
            <h2 style="font-size: 2VW;">Wat is jouw motivatie om voor Krits te komen werken?</h2>
        </div>
        <div>
            <form method="POST" action="/motivatiebrief/save">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="gebruiker_id" value="<?php echo e($gebruiker_id); ?>">
                <input type="text" id="motivatiebrief" name="motivatiebrief" hidden="hidden"><br>
                <button id="end-button" type="submit">Verzenden</button>
            </form>
        </div>
    </div>

    <div id="motivatiebriefContainer">
        <input type="text" id="motivatiebriefInput" name="motivatiebriefInput">
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>

<script>
    //input motivatiebrief value


    //einde van test
    const endButton = document.querySelector('#end-button');
    endButton.addEventListener('click', (e) => {
        e.preventDefault();

        const motivatiebrief = document.getElementById('motivatiebriefInput').value;
        document.getElementById('motivatiebrief').value = motivatiebrief;
        document.querySelector('form').submit();
    });

    /*function endMotivatiebrief(e) {
        e.preventDefault();
        //window.close();
        alert('Dankje voor je tijd.');
    }*/
</script>

<style>
    body{
        color: white;
        background-color: #272726;
    }

     .testNav{
         height: 100px;
         display: flex;
         padding-top: 20px;
         align-items: center;
         justify-content: space-around;
     }

     #end-button{
         color:white;
         padding: 10px;
         font-size: 2VW;
         border-radius: 10px;
         border: 1px solid #E7FD52;
         background-color: #373934;
     }


    #motivatiebriefContainer, footer{
        color: grey;
        display: flex;
        justify-content: space-around;
    }

    footer{
        left:42%;
        position: absolute;
        bottom: 5px;
    }
</style>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/emails/motivatiebrief.blade.php ENDPATH**/ ?>