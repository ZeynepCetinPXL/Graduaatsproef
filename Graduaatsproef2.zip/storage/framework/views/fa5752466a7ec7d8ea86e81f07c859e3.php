<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>authenticatie</title>
</head>
<body>
    <form action="<?php echo e(route('password.authenticate')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="password">Enter Password:</label>
        <input type="password" name="password" id="password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit">Authenticate</button>
    </form>
</body>
</html>



<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/auth/password.blade.php ENDPATH**/ ?>