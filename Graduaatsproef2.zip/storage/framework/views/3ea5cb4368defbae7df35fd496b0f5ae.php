<html>
<body>
    <h1>Dankje voor je interessen</h1>
    <p>
        We hebben besloten om verder te gaan met andere kandidaten.<br>
        We hopen dat we jouw in de toekomst nog terug zien!
    </p>
</body>
</html>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/emails/mailGefaald.blade.php ENDPATH**/ ?>