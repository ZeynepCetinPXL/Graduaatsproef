<html>
<body>
    <h1>Dankje voor je interesse in deze positie.</h1>
    <br>
        We zouden graag wat meer over je willen weten, probeer onze test eens uit? </br>
        Let op, het moment dat je drukt op de onderstaande knop zal er een timer afgaan.
    </p>
    <a href="http://graduaatsproef.test/test?id=<?php echo e($gebruiker_id); ?>" id="navLink">Testen</a>
</body>
</html>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/emails/fase1Mail.blade.php ENDPATH**/ ?>
