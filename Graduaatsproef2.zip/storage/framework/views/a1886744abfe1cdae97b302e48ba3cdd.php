<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Test</title>
</head>
<body>
    <header class="testNav">
        <div>
            <img src="<?php echo e(URL::asset('assets/logo.svg')); ?>" width="100px" alt="logo">
        </div>
        <div>
            <h2 style="font-size: 2VW;">Wat kan er volgens jou beter aan het onderstaande design?</h2>
        </div>
        <div class="formButton">
            <form method="POST" action="/test/save">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="gebruiker_id" value="<?php echo e($gebruiker_id); ?>">
                <input type="text" id="score" name="score" hidden="hidden"><br>
                <input type="text" id="status" name="status" hidden="hidden"><br>
                <button id="end-button" type="submit">Verzenden</button>
            </form>
        </div>
    </header>

    <div class="testNav">
        <h1><span id="timer">10:00</span></h1>
        <p>Score: <span id="scoreTest">0</span></p>
    </div>
    <div id="container">
        <div id="imageContainer">
            <img id="imageWrong" src="<?php echo e(URL::asset('assets/UI_Mistakes.png')); ?>" alt="test afbeelding">
            <img id="imageRight" src="<?php echo e(URL::asset('assets/UI_Good.png')); ?>" alt="test afbeelding">
        </div>

        <div id="testContainer">
            <div class="big" style="top: 0; left: 100px; width: 50px; height: 20px;"></div>
            <div class="big" style="top: 220px; left: 1px; width: 45px; height: 45px;"></div>
            <div class="mid" style="top: 0; left: 42px; width: 20px; height: 20px;"></div>
            <div class="mid" style="top: 210px; left: 335px; width: 50px; height: 25px;"></div>
            <div class="mid" style="top: 380px; left: 260px; width: 70px; height: 20px;"></div>
            <div class="mid" style="top: 380px; left: 40px; width: 40px; height: 20px;"></div>
            <div class="small" style="top: 50px; left: 250px; width: 95px; height: 105px;"></div>
            <div class="small" style="top: 135px; left: 40px; width: 170px; height: 55px;"></div>
            <div class="small" style="top: 150px; left: 310px; width: 100px; height: 40px;"></div>
            <div class="small" style="top: 245px; left: 60px; width: 60px; height: 25px;"></div>
            <div class="none" style="top: 120px; left: 300px; width: 50px; height: 60px;"></div>
        </div>
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>

<script>
    const endButton = document.querySelector('#end-button');
    const scoreElement = document.getElementById('scoreTest');

    //aanduiding gebruiker - img
    const circles = [];
    const image = document.getElementById('imageWrong');
    const testContainer = document.getElementById("testContainer");
    const imageContainer = document.getElementById("imageContainer");

    let score = 0;
    let maxScore = 18;
    let status = 'blub';
    let timeRemaining = 600;
    let timerId = setInterval(updateTime, 1000);

    /* timer van 10 min */
    function updateTime() {
        const minutes =Math.floor(timeRemaining/60);
        const seconds = timeRemaining % 60;

        document.getElementById('timer').innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        timeRemaining--;

        if ( timeRemaining < 0) {
            endTest();
        }
    }

    //plaatsen en verwijderen van cirkels op de afbeedling & punten
    testContainer.addEventListener('click', function (event) {
        const target = event.target;

        //groot punt - 3
        if (target.classList.contains('big')) {
            const bigElement = target;

            if (bigElement.classList.contains('selected')) {
                bigElement.classList.remove('selected');
                score -= 3;

                //cirkel verwijderen
                const associatedCircle = bigElement.querySelector('.circle');
                if (associatedCircle) {
                    associatedCircle.remove();
                }
            } else {
                bigElement.classList.add('selected');

                //cirkel toevoegen
                const rect = target.getBoundingClientRect();
                const offsetX = event.clientX - rect.left - window.scrollX - 15;
                const offsetY = event.clientY - rect.top - imageContainer.getBoundingClientRect().top - window.scrollY - 8;
                const circle = document.createElement('div');

                circle.classList.add('circle');
                circle.style.left = offsetX + 'px';
                circle.style.top = offsetY + 'px';

                bigElement.appendChild(circle);

                score += 3;
            }
            scoreElement.textContent = score;
        }
        //medium punt - 2
        if (target.classList.contains('mid')) {
            const midElement = target;

            if (midElement.classList.contains('selected')) {
                midElement.classList.remove('selected');
                score -= 2;

                //cirkel verwijderen
                const associatedCircle = midElement.querySelector('.circle');
                if (associatedCircle) {
                    associatedCircle.remove();
                }
            } else {
                midElement.classList.add('selected');

                //cirkel toevoegen
                const rect = target.getBoundingClientRect();
                const offsetX = event.clientX - rect.left - window.scrollX - 15;
                const offsetY = event.clientY - rect.top - imageContainer.getBoundingClientRect().top - window.scrollY - 8;
                const circle = document.createElement('div');

                circle.classList.add('circle');
                circle.style.left = offsetX + 'px';
                circle.style.top = offsetY + 'px';

                midElement.appendChild(circle);

                score += 2;
            }
            scoreElement.textContent = score;
        }
        //klein punt - 1
        if (target.classList.contains('small')) {
            const smallElement = target;

            if (smallElement.classList.contains('selected')) {
                smallElement.classList.remove('selected');
                score --;

                //cirkel verwijderen
                const associatedCircle = smallElement.querySelector('.circle');
                if (associatedCircle) {
                    associatedCircle.remove();
                }
            } else {
                smallElement.classList.add('selected');
                score ++;

                //cirkel toevoegen
                const rect = target.getBoundingClientRect();
                const offsetX = event.clientX - rect.left - window.scrollX - 15;
                const offsetY = event.clientY - rect.top - imageContainer.getBoundingClientRect().top - window.scrollY - 8;
                const circle = document.createElement('div');

                circle.classList.add('circle');
                circle.style.left = offsetX + 'px';
                circle.style.top = offsetY + 'px';

                smallElement.appendChild(circle);
            }
            scoreElement.textContent = score;
        }
        //cirkel toevoegen - testContainer -> geen punten
        else if (target.classList.contains("circle")) {
            target.parentNode.removeChild(target);
            const index = circles.indexOf(target);
            if (index !== -1) {
                circles.splice(index, 1);
            }
        }else if (!target.classList.contains("selected")) {
            const containerRect = testContainer.getBoundingClientRect();
            const imageContainerRect = imageContainer.getBoundingClientRect();

            const offsetX = event.clientX - containerRect.left - window.scrollX - 15;
            const offsetY = event.clientY - containerRect.top - imageContainerRect.top - window.scrollY - 8;
            const circle = document.createElement("div");

            circle.classList.add("circle");
            circle.style.left = offsetX + "px";
            circle.style.top = offsetY + "px";
            circles.push(circle);
            testContainer.appendChild(circle);
        }
    });


    //einde van test - status en eindscore
    endButton.addEventListener('click', endTest);

    function endTest() {
        clearInterval(timerId);
        if(score > (maxScore/2)){
            //status = 'geslaagd';
            document.getElementById('status').value = 'geslaagd';
        }else{
            //status = 'gefaald';
            document.getElementById('status').value = 'gefaald';
        }
        document.getElementById('score').value = score;
    }

    //de test container verandert met de page width en height - responsive
    const imageWrong = document.getElementById('imageWrong');

    function updateContainerSize() {
        const imageWidth = imageWrong.offsetWidth;
        const imageHeight = imageWrong.offsetHeight;
        const imageWrongPosition = imageWrong.getBoundingClientRect();

        testContainer.style.width = imageWidth + 'px';
        testContainer.style.height = imageHeight + 'px';
        testContainer.style.position = 'absolute';
        testContainer.style.left = imageWrongPosition.left + 'px';
    }

    window.addEventListener('load', updateContainerSize);
    window.addEventListener('resize', updateContainerSize);
</script>

<style>
    /* Als je de aantal score wilt zien*/
    .testNav p{
        display: none;
    }

    body{
        margin: 0;
        color: white;
        background-color: #272726;
    }

     .testNav{
         height: 100px;
         display: flex;
         padding-top: 20px;
         align-items: center;
         justify-content: space-around;
     }

     .formButton{
         margin-bottom: 3%;
         align-content: center;
     }

     #end-button{
         color:white;
         padding: 10px;
         font-size: 2vw;
         border-radius: 10px;
         border: 1px solid #E7FD52;
         background-color: #373934;
     }

    .small{
        position: absolute;
        /*border: 2px solid green;*/
    }
    .mid{
        position: absolute;
        /*border: 2px solid orange;*/
    }
    .big{
        position: absolute;
        /*border: 2px solid red;*/
    }

    #container {
        z-index: 1;
        display: flex;
        position: relative;
        padding-bottom: 100px;
        justify-content: space-around;
    }

    #imageContainer {
        gap: 50px;
        display: flex;
        flex-wrap: wrap;
        position: relative;
        justify-content: space-around;
    }

    #imageContainer img {
        max-width: 450px;
        height: auto;
    }

    #testContainer{
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        position: absolute;
        justify-content: space-around;
    }

    .circle{
        width: 20px;
        height: 20px;
        margin-top: 235px;
        border-radius: 50%;
        position: absolute;
        border: 2px solid #E7FD52;
    }

    footer{
        left: 0;
        right: 0;
        bottom: 0;
        color: grey;
        margin: 0 auto;
        position: fixed;
        text-align: center;
    }
</style>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/processen/test.blade.php ENDPATH**/ ?>
