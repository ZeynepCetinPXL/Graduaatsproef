<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/dashboardStyle.css')); ?>">
</head>
<body>
    <div id="navigatie">
        <div id="navigatieLogo" style="background-image:url('<?php echo e(asset('assets/bb2.png')); ?>'); background-repeat: no-repeat; background-size:cover">
            <img src="<?php echo e(URL::asset('assets/logo.svg')); ?>" alt="logo">
        </div>
        <div id="navigatieLink">
            <a href="/dashboard" id="navLink">Sollicitaties</a>
            <a href="/dashboard_vacatures">Vacatures</a>
            <a href="/dashboard_testen">Testen</a>
        </div>

        <div id="navigatieExtra">
            <img src="<?php echo e(URL::asset('assets/bob.svg')); ?>" alt="bob">
            <p>Graduaatproef Zeynep</p>
        </div>
    </div>

    <table id="tabel">
        <tr>
            <th>Gebruiker</th>
            <th>Vacature</th>
            <th>Test resultaten</th>
            <th>Motivatiebrief</th>
            <th>Resultaat</th>
        </tr>

        <?php $__currentLoopData = $gebruikers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gebruiker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td># <?php echo e($gebruiker->id); ?></td>
            <td>designer</td>
            <td>
                <?php if($gebruiker->score): ?>
                    <?php echo e($gebruiker->score->score); ?>/18
                <?php else: ?>
                    in afwachting
                <?php endif; ?>
            </td>
            <td class="motivatiebrief" >motivatiebrief</td>
            <td class="motivatiebriefResultaat"> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
           <td>ID</td>
            <td>designer</td>
            <td>score</td>
            <td class="motivatiebrief"></td>
            <td class="motivatiebriefResultaat"></td>
        </tr>

    </table>

    <div class="popupMotivatieStatus">
        <div class="popupInfo" id="myPopup">
            <div class="popupHead">
                <div>
                    <button onclick="togglePopup()">X</button>
                </div>
            </div>
            <div>
                <h3 class="popupInfo">Ben je zeker over je keuzen?</h3>
                <p class="popupInfo" id="motivatiebriefKeuzen"></p>

                <form method="POST" action="/MotivatieSave/save">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="gebruiker_id" value="1">
                    <input type="text" id="status" name="status" hidden="hidden"><br>
                    <button id="end-button" type="submit">Versturen</button>
                </form>
            </div>
        </div>
    </div>
    <div class="overlayDiv">
        <div class="overlay"></div>
    </div>

</body>
</html>

<script>
    //popup sluiten
    function togglePopup(){
        const popup = document.getElementById('myPopup');
        popup.classList.toggle("show");

        //overlay sluiten
        const overlay = document.getElementsByClassName("overlay");
        overlay.classList.toggle("show");
    }

    //toggle voor extra confirmatie en motivatie goedgekeurd
    function togglePopupAccept(){
        motivatieStatus = 'goedgekeurd';
        const motivatieResultaat = document.getElementById('status').value = motivatieStatus;
        document.getElementById('motivatiebriefKeuzen').innerHTML = '"'+ motivatieStatus + '"';
        //popup tonen
        document.getElementById('myPopup').classList.toggle("show");

        //overlay tonen
        //document.getElementsByClassName("overlay").classList.toggle("show");
    }

    //toggle voor extra confirmatie en motivatie NIET goedgekeurd
    function togglePopupReject(){
        motivatieStatus = 'afgewezen';

        const motivatieResultaat = document.getElementById('status').value = motivatieStatus;
        document.getElementById('motivatiebriefKeuzen').innerHTML = '"'+ motivatieStatus + '"';
        //popup tonen
        document.getElementById('myPopup').classList.toggle("show");

        //overlay sluiten
        //const overlay = document.getElementsByClassName("overlay");
        //overlay.classList.toggle("show");
    }

    //Roep alle rijen in de tabel - loop
    const rows = document.querySelectorAll("#tabel tr");

    //loop door elke rij
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const motivatiebriefCell = row.querySelector(".motivatiebrief");
        const motivatiebriefResultaatCell = row.querySelector(".motivatiebriefResultaat");

        //controleert of de motivatiebrief leeg is
        if (motivatiebriefCell.textContent.trim() === "") {
            //leegte omzetten naar -> "In afwachting"
            motivatiebriefCell.textContent = "In afwachting";
            motivatiebriefResultaatCell.textContent = "In afwachting";
        } else {
            const buttonContainer = document.createElement("div");
            buttonContainer.className = "buttonDiv";

            const rejectButton = document.createElement("button");
            rejectButton.textContent = "X";
            rejectButton.className = "buttonMotive";
            rejectButton.addEventListener("click", togglePopupReject);

            const acceptButton = document.createElement("button");
            acceptButton.textContent = "V";
            acceptButton.className = "buttonMotive";
            acceptButton.addEventListener("click", togglePopupAccept);

            //de knoppen plaatsen in de resultaat div
            buttonContainer.appendChild(acceptButton);
            buttonContainer.appendChild(rejectButton);

            //de div plaatsen in de lege cel
            motivatiebriefResultaatCell.appendChild(buttonContainer);
        }
    }

    //inzending keuzen
    const endButton = document.querySelector('#end-button');
    endButton.addEventListener('click', endMotive);

    function endMotive(){
        const motivatiebriefStatus = document.getElementById('status').value;
        alert(motivatiebriefStatus);
    }
</script>

<style>
    body{
        background-size:cover;
        background-color: #373934;
        background-repeat: no-repeat;
        background-image:url('<?php echo e(asset('assets/bb.png')); ?>');
    }

    .buttonDiv{
        display: flex;
        justify-content: space-around;
    }

    .buttonMotive{
        cursor:pointer;
        border-radius: 12px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        padding: 6px 12px 6px 12px;
    }

    .popupMotivatieStatus{
        top: 50%;
        left: 50%;
        width: 35%;
        z-index: 9999;
        position: fixed;
        visibility: hidden;
        transform: translate(-50%, -50%);
    }

    .popupMotivatieStatus .show {
        visibility: visible;
    }

    #myPopup{
        background-color: #31342C;
        border-radius: 20px;
    }

    .popupHead{
        display: flex;
    }

    .popupHead > div{
        width: 100%;
        margin: 20px 20px 0 20px;
        text-align: right;
    }

    .popupHead button{
        height: 30px;
        cursor:pointer;
        border-radius: 12px;
        border: 1px solid #E7FD52;
        background-color: #373934;
    }

    .popupInfo{
        text-align: center;
    }

    #end-button{
        padding: 10px;
        cursor:pointer;
        border-radius: 12px;
        margin-bottom: 40px;
        border: 2px solid #E7FD52;
        background-color: #373934;
    }

    .overlayDiv{
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9998;
        position: fixed;
        visibility: hidden;
        background-color: rgba(173, 16, 16, 0.7);
    }

    .overlay .show{
        visibility: visible;
    }
</style>


<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/dashboards/dashboard_sollicitaties.blade.php ENDPATH**/ ?>
