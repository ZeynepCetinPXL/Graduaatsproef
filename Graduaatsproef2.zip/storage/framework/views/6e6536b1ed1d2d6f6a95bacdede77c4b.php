<html>
<body>
    <h1>Dankje voor je tijd.</h1>
    <p>
        We zijn erg onder de indruk van je motivatiebrief! <br>
        We zouden graag wat meer over jouw willen bijleren door je eens daadwerkelijk te ontmoeten.
        Boek een dag in onze agenda: URL.
    </p>
    <a href="http://sollicitatie.krits.be/motivatiebrief?id=<?php echo e($gebruiker_id); ?>" id="navLink">Testen</a>
</body>
</html>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/emails/fase3MailGeslaagd.blade.php ENDPATH**/ ?>