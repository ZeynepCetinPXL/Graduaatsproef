<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/dashboardStyle.css')); ?>">
</head>

<body>
    <button class="knop" onclick="window.location.href='http://graduaatsproef.test/email';">solliciteren</button>
</body>
</html>

<style>
    .knop{
        padding: 10px;
        cursor:pointer;
        border-radius: 12px;
        border: 2px solid #E7FD52;
        background-color: #373934;
    }
</style>

<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/emails/start.blade.php ENDPATH**/ ?>
