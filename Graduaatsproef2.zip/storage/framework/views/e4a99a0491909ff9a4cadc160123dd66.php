<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/dashboardStyle.css')); ?>">
</head>

<body>
<div id="navigatie">
    <div id="navigatieLogo" style="background-image:url('<?php echo e(asset('assets/bb2.png')); ?>'); background-repeat: no-repeat; background-size:cover">
        <img src="<?php echo e(URL::asset('assets/logo.svg')); ?>">
    </div>
    <div id="navigatieLink">
        <a href="/dashboard">Sollicitaties</a>
        <a href="/dashboard_vacatures" id="navLink">Vacatures</a>
        <a href="/dashboard_testen">Testen</a>
    </div>

    <div id="navigatieExtra">
        <img src="<?php echo e(URL::asset('assets/bob.svg')); ?>">
        <p>Graduaatproef Zeynep</p>
    </div>
</div>

<table id="tabel">
    <tr>
        <th>ID</th>
        <th>Vacature</th>
        <th>Samenvatting</th>
        <th>Test</th>
        <th>Status</th>
        <th>Aantal</th>
    </tr>
    <?php $__currentLoopData = $vacatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($vacature['id']); ?></td>
        <td><?php echo e($vacature['naam']); ?></td>
        <td><?php echo e($vacature['samenvatting']); ?></td>
        <td><?php echo e($vacature['test_id']); ?></td>
        <td><?php echo e($vacature['status']); ?></td>
        <td></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html>
<style>
    body{
        background-size:cover;
        background-color: #373934;
        background-repeat: no-repeat;
        background-image:url('<?php echo e(asset('assets/bb.png')); ?>');
    }
</style>

<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/dashboards/dashboard_vacatures.blade.php ENDPATH**/ ?>
