<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Motivatiebrief</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/dashboardStyle.css')); ?>">
</head>
<body>
    <header>
        <div id="logo">
            <img src="<?php echo e(URL::asset('assets/logo.svg')); ?>" width="100px" alt="logo">
        </div>
        <div>
            <h2 style="font-size: 2VW;">Wat is jouw motivatie om voor Krits te komen werken?</h2>
        </div>
        <div id="bob">
            <img src="<?php echo e(URL::asset('assets/bob.svg')); ?>" alt="bob">
        </div>
    </header>

    <div class="popup">
        <div class="popupInfo">
            <div class="popupHead">
                <div>
                    <h1>Motivatiebrief</h1>
                </div>
            </div>
            <div>
                <form method="POST" action="/motivatiebrief/save">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="gebruiker_id" value="<?php echo e($gebruiker_id); ?>">
                    <textarea id="motivatiebrief" name="motivatiebrief" required> </textarea> <br>
                    <button type="submit" class="knop">Verzenden</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>

<style>
    body{
        color: white;
        background-color: #272726;
    }

    header{
        height: 100px;
        display: flex;
        margin: 0 -5px;
        padding-top: 20px;
        align-items: center;
        justify-content: space-between;
    }

    #logo{
        margin-left: 50px;
    }

    #bob img{
        width: auto;
        height: 120px;
    }

    .popup{
        margin: 40px;
        display: flex;
        text-align: center;
        align-items: center;
        justify-content: space-around;
    }

    .popupInfo{
        width: 80%;
        border-radius: 20px;
        padding: 10px 0 50px 0;
        background-color: #31342C;
    }

    .popupHead{
        display: flex;
        justify-content: space-around;
    }

    .popupHead div{
        width: 100%;
        margin-top: 20px;
        text-align: center;
    }

    #motivatiebrief{
        width: 80%;
        padding: 5px;
        height: 300px;
        color: #373934;
        border-radius: 5px;
        margin:  10px 40px 40px 40px;

    }

    .knop{
        cursor:pointer;
        border-radius: 12px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        padding: 10px 20px 10px 20px;
    }

    footer{
        width: 98%;
        text-align: center;
        position: absolute;
    }

    @media(max-height: 780px){
        footer{
            bottom: -10%;
        }
    }

</style>
<?php /**PATH /Users/krits02/Sites/graduaatsproef/resources/views/processen/motivatiebrief.blade.php ENDPATH**/ ?>
