<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="{{ URL::asset('css/dashboardStyle.css') }}">
</head>

<body>
<header id="navigatie">
    <div id="navigatieLogo" style="background-image:url('{{ asset('assets/bb2.png')}}'); background-repeat: no-repeat; background-size:cover">
        <img src="{{ URL::asset('assets/logo.svg') }}" alt="logo">
    </div>
    <div id="navigatieLink">
        <a href="/dashboard">Sollicitaties</a>
        <a href="/dashboard_vacatures">Vacatures</a>
        <a href="/dashboard_testen" id="navLink">Testen</a>
    </div>

    <div id="navigatieExtra">
        <img src="{{ URL::asset('assets/bob.svg') }}" alt="bob">
        <p>Graduaatproef Zeynep</p>
    </div>
</header>

    <table id="tabel">
        <tr>
            <th>ID</th>
            <th>Naam</th>
            <th>Samenvatting</th>
        </tr>
        @foreach($testen as $test)
            <tr>
                <td>{{$test['id']}}</td>
                <td>{{$test['naam']}}</td>
                <td>{{$test['samenvatting']}}</td>
            </tr>
        @endforeach
    </table>

<footer>
    <p>Graduaatproef Zeynep Çetin</p>
</footer>
</body>
</html>
<style>
    body{
        background-size:cover;
        background-color: #373934;
        background-repeat: no-repeat;
        background-image:url('{{ asset('assets/bb.png')}}');
    }

    #navigatieLink a{
        font-size: xx-large;
    }

    @media(max-width: 1000px) {
        #navigatieLink a{
            font-size: x-large;
        }
    }

        footer {
        display: none;
    }
</style>
