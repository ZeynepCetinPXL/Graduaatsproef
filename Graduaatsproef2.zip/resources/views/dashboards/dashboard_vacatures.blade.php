<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="{{ URL::asset('css/dashboardStyle.css') }}">
</head>

<body>
<header id="navigatie">
    <div id="navigatieLogo" style="background-image:url('{{ asset('assets/bb2.png')}}'); background-repeat: no-repeat; background-size:cover">
        <img src="{{ URL::asset('assets/logo.svg') }}">
    </div>
    <div id="navigatieLink">
        <a href="/dashboard">Sollicitaties</a>
        <a href="/dashboard_vacatures" id="navLink">Vacatures</a>
        <a href="/dashboard_testen">Testen</a>
    </div>

    <div id="navigatieExtra">
        <img src="{{ URL::asset('assets/bob.svg') }}">
        <p>Graduaatproef Zeynep</p>
    </div>
</header>

<table id="tabel">
    <tr>
        <th>ID</th>
        <th>Vacature</th>
        <th>Samenvatting</th>
        <th>Test</th>
        <th>Status</th>
    </tr>

    @foreach($vacatures as $vacature)
    <tr>
        <td>{{$vacature['id']}}</td>
        <td>{{$vacature['naam']}}</td>
        <td>{{$vacature['samenvatting']}}</td>
        <td>{{$vacature['test_id']}}</td>
        <td>{{$vacature['status']}}</td>
    </tr>
    @endforeach
</table>

<footer>
    <p>Graduaatproef Zeynep Çetin</p>
</footer>

</body>
</html>
<style>
    body{
        background-size:cover;
        background-color: #373934;
        background-repeat: no-repeat;
        background-image:url('{{ asset('assets/bb.png')}}');
    }

    #navigatieLink a{
        font-size: xx-large;
    }

    @media(max-width: 1000px) {
        #navigatieLink a{
            font-size: x-large;
        }
    }

    footer {
        display: none;
    }
</style>

