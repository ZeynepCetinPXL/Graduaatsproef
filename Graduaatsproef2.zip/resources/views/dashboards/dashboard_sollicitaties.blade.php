<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="{{ URL::asset('css/dashboardStyle.css') }}">
</head>
<body>
    <header id="navigatie">
        <div id="navigatieLogo" style="background-image:url('{{ asset('assets/bb2.png')}}'); background-repeat: no-repeat; background-size:cover">
            <img src="{{ URL::asset('assets/logo.svg') }}" alt="logo">
        </div>
        <div id="navigatieLink">
            <a href="/dashboard" id="navLink">Sollicitaties</a>
            <a href="/dashboard_vacatures">Vacatures</a>
            <a href="/dashboard_testen">Testen</a>
        </div>

        <div id="navigatieExtra">
            <img src="{{ URL::asset('assets/bob.svg') }}" alt="bob">
            <p>Graduaatproef Zeynep</p>
        </div>
    </header>

    <table id="tabel">
        <tr>
            <th>Gebruiker</th>
            <th>Vacature</th>
            <th>Test resultaten</th>
            <th>Motivatiebrief</th>
            <th>Resultaat</th>
        </tr>

        <div class="tableScroll">
            @foreach($gebruikers as $gebruiker)
                <tr>
                    <td class="gebruikerID"># {{ $gebruiker->id }}</td>
                    <td>designer</td>
                    <td class="testResultaat">
                        @if ($gebruiker->score)
                            {{ $gebruiker->score->score }}/18
                        @else
                            in afwachting
                        @endif
                    </td>
                    <td class="motivatiebrief">
                        @if (isset($gebruiker->motivatiebrief))
                            {{ $gebruiker->motivatiebrief->motivatiebrief }}
                        @else
                            in afwachting
                        @endif
                    </td>
                    <td class="motivatiebriefResultaat"> </td>
                    <td class="motivatiebriefStatus" style="display: none"> @if (isset($gebruiker->motivatiebrief))
                            {{ $gebruiker->motivatiebrief->status }}
                        @else
                            leeg
                        @endif
                    </td>
                </tr>
            @endforeach
        </div>
    </table>

    <div class="popupMotivatieStatus">
        <div class="popupInfo" id="myPopup">
            <div class="popupHead">
                <div style="width: 10%"> </div>
                <div>
                    <h1>Motivatiebrief</h1>
                </div>
                <div>
                    <button onclick="togglePopup()">X</button>
                </div>
            </div>
            <div class="formMotivatiebrief">
                <div class="formMotivatiebriefInhoud">
                    <!--<p id="motivatiebriefKeuzen"></p>-->
                    <p id="motivatiebriefInhoud"></p>
                    <!--<p id="gebruiker_idText"></p>-->
                </div>
                <div class="formMotivatiebriefButton">
                    <form method="POST" action="/motivatiebriefResultaat/save">
                        @csrf
                        <input type="text" id="gebruiker_id" name="gebruiker_id" hidden="hidden"><br>
                        <input type="text" id="status" name="status" hidden="hidden"><br>
                        <button id="end-button" type="submit"> </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="overlayDiv">
        <div id="overlay"></div>
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>

<script>
    //popup sluiten
    function togglePopup(){
        const popup = document.getElementById('myPopup');
        popup.classList.toggle("show");

        //overlay sluiten
        const overlay = document.getElementById("overlay");
        overlay.classList.toggle("show");
    }

    //toggle voor extra confirmatie en motivatie goedgekeurd
    function togglePopupAccept(){
        //motivatie status
        motivatieStatus = 'goedgekeurd';
        const motivatieResultaat = document.getElementById('status').value = motivatieStatus;
        //document.getElementById('motivatiebriefKeuzen').innerHTML = '"'+ motivatieResultaat + '"';

        //motivatie inhoud
        const motivatiebriefInhoud = this.closest('tr').querySelector('.motivatiebrief').textContent.trim();
        document.getElementById('motivatiebriefInhoud').innerHTML = motivatiebriefInhoud;

        //gebruiker id
        const gebruikerID = this.closest('tr').querySelector('.gebruikerID').textContent.trim();
        document.getElementById('gebruiker_id').value = parseInt(gebruikerID.substring(1));
        //document.getElementById('gebruiker_idText').innerHTML = trimmedID;

        //button
        document.getElementById('end-button').innerHTML = 'Goedkeuren';

        //popup & overlay tonen
        document.getElementById('myPopup').classList.toggle("show");
        document.getElementById("overlay").classList.toggle("show");
    }

    //toggle voor extra confirmatie en motivatie NIET goedgekeurd
    function togglePopupReject(){
        motivatieStatus = 'afgewezen';
        const motivatieResultaat = document.getElementById('status').value = motivatieStatus;
        //document.getElementById('motivatiebriefKeuzen').innerHTML = '"'+ motivatieResultaat + '"';

        //motivatie inhoud
        const motivatiebriefInhoud = this.closest('tr').querySelector('.motivatiebrief').textContent.trim();
        document.getElementById('motivatiebriefInhoud').innerHTML = motivatiebriefInhoud;

        //gebruiker id
        const gebruikerID = this.closest('tr').querySelector('.gebruikerID').textContent.trim();
        document.getElementById('gebruiker_id').value = parseInt(gebruikerID.substring(1));
        //document.getElementById('gebruiker_idText').innerHTML = trimmedID;

        //button
        document.getElementById('end-button').innerHTML = 'Afwijzen';

        //popup & overlay tonen
        document.getElementById('myPopup').classList.toggle("show");
        document.getElementById("overlay").classList.toggle("show");
    }

    //Roep alle rijen in de tabel - loop
    const rows = document.querySelectorAll("#tabel tr");

    //loop door elke rij voor 'Afgerond' & 'In afwachting' & de knoppen
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const testResultaatCell = row.querySelector(".testResultaat")
        const motivatiebriefCell = row.querySelector(".motivatiebrief");
        const motivatiebriefStatus = row.querySelector('.motivatiebriefStatus');
        const motivatiebriefResultaatCell = row.querySelector(".motivatiebriefResultaat");

        //testresltaten -> 'afgerond' ipv 'in afwachting'
        const testResultaatText = testResultaatCell.textContent.trim();
        const testResultaatScore = parseInt(testResultaatText.substring(0, 2));

        //controleert of de gebruiker is geslaagd op de test
        if (testResultaatScore < 9) {
            motivatiebriefCell.textContent = "Afgerond";
            motivatiebriefResultaatCell.textContent = "Afgerond";
        }
        //controleert of de motivatiebrief leeg is
        else if (motivatiebriefCell.textContent.trim() === "in afwachting") {
            //leegte omzetten naar -> "In afwachting"
            motivatiebriefCell.textContent = "In afwachting";
            motivatiebriefResultaatCell.textContent = "In afwachting";
        }else if(motivatiebriefStatus.textContent.trim() !== ''){
            if (motivatiebriefStatus.textContent.trim() === 'goedgekeurd') {
                //knop 'Goedgekeurd'
                var button = document.createElement('button');
                button.textContent = 'Goedgekeurd';
                button.className = "buttonStatus";
                button.classList.add('goedgekeurd-button');

                //Bestaande knoppen verwijderen & nieuwe toevoegen
                motivatiebriefResultaatCell.innerHTML = '';
                motivatiebriefResultaatCell.appendChild(button);
            } else if (motivatiebriefStatus.textContent.trim() === 'afgewezen') {
                //knop 'Afgewezen'
                var button = document.createElement('button');
                button.textContent = 'Afgewezen';
                button.className = "buttonStatus";
                button.classList.add('afgewezen-button');

                //Bestaande knoppen verwijderen & nieuwe toevoegen
                motivatiebriefResultaatCell.innerHTML = '';
                motivatiebriefResultaatCell.appendChild(button);
            }
        }
        else {
            const buttonContainer = document.createElement("div");
            buttonContainer.className = "buttonDiv";

            const rejectButton = document.createElement("button");
            rejectButton.textContent = "X";
            rejectButton.className = "buttonMotive";
            rejectButton.addEventListener("click", togglePopupReject);

            const acceptButton = document.createElement("button");
            acceptButton.textContent = "V";
            acceptButton.className = "buttonMotive";
            acceptButton.addEventListener("click", togglePopupAccept);

            //de knoppen plaatsen in de resultaat div
            buttonContainer.appendChild(acceptButton);
            buttonContainer.appendChild(rejectButton);

            //de div plaatsen in de lege cel
            motivatiebriefResultaatCell.appendChild(buttonContainer);
        }
    }

    //inzending keuzen
    const endButton = document.querySelector('#end-button');
    endButton.addEventListener('click', endMotive);

    function endMotive(){
        const motivatiebriefStatus = document.getElementById('status').value;
        // sluit popup
        document.getElementById('myPopup').classList.remove('show');
        // sluit overlay
        document.querySelector('.overlayDiv').style.display = 'none';
    }
</script>

<style>
    body{
        background-size:cover;
        background-color: #373934;
        background-repeat: no-repeat;
        background-image:url('{{ asset('assets/bb.png')}}');
    }

    .buttonDiv{
        display: flex;
        justify-content: space-around;
    }

    .buttonMotive{
        cursor:pointer;
        border-radius: 12px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        padding: 6px 12px 6px 12px;
    }

    .buttonStatus{
        margin: auto;
        cursor: auto;
        display: flex;
        border-radius: 12px;
        align-items: center;
        justify-content: center;
        border: 2px solid #E7FD52;
        background-color: #373934;
        padding: 6px 12px 6px 12px;
    }

    .popupMotivatieStatus{
        top: 50%;
        left: 50%;
        width: 80%;
        z-index: 9999;
        position: fixed;
        visibility: hidden;
        transform: translate(-50%, -50%);
    }

    .popupMotivatieStatus .show {
        visibility: visible;
    }

    .popupInfo{
        text-align: center;
    }

    #myPopup{
        border-radius: 20px;
        background-color: #31342C;
    }

    .popupHead{
        top: 0;
        left: 0;
        width: 100%;
        height: 80px;
        display: flex;
        position: fixed;
        align-items: center;
        background-color: #272726;
        border-radius: 20px 20px 0 0;
        justify-content: space-between;
    }

    .popupHead button{
        border: none;
        cursor:pointer;
        font-size: x-large;
        padding-right: 25px;
        background-color: transparent;
    }

    .formMotivatiebrief{
        display: flex;
        align-items: center;
        align-content: center;
        flex-direction: column;
    }

    .fromMotivatiebrief div:nth-child(2) {
        height: 50px;
    }

    .formMotivatiebrief p{
        margin-top: 80px;
        margin-bottom: -5px;
        padding: 40px 80px 0 80px;
    }

    #end-button{
        padding: 10px;
        cursor:pointer;
        border-radius: 12px;
        margin-bottom: 40px;
        border: 2px solid #E7FD52;
        background-color: #373934;
    }

    #overlay {
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9998;
        position: fixed;
        visibility: hidden;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
    }

    #overlay.show {
        visibility: visible;
    }

    .motivatiebrief{
        max-width: 250px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .motivatiebriefResultaat{
        min-width: 105px;
    }

    footer{
        width: 98%;
        bottom: 5px;
        display: none;
        text-align: center;
        position: absolute;
    }

    #navigatieLink a {
        font-size: xx-large;
    }

    table td{
        height: 30px;
        padding: 8px;
        background-color: #31342C;
        border: 1px solid #272726;
    }

    @media(max-width: 1000px){
        table {
            left: 0;
            right: 0;
            width: 80%;
            position: absolute;
            margin: 150px auto 0;
            border-collapse: collapse;
            border-radius: 20px 20px 0 0;
        }

        #navigatie{
            top: 0;
            left: 0;
            width: 100%;
            height: 100px;
            display: flex;
            position: fixed;
            background-color: #31342C;
            flex-direction: row-reverse;
            justify-content: space-between;
        }

        #navigatieLogo img{
            width: auto;
            height: 80px;
            margin: 8px 40px 0 40px;
        }

        #navigatieLink{
            display: flex;
            justify-content: center;
        }

        #navigatieLink a{
            display: inline-flex;
            align-items: center;
            font-size: x-large;
            font-weight: bold;
            transition: 0.3s;
            text-decoration: none;
            padding: 10px 10px 10px 25px;
            background-color: transparent;
        }

        #navigatieExtra img{
            width: auto;
            height: 80px;
            float: left;
            margin-top: 10px;
            transform: scaleX(-1);
            background-color: transparent;
        }

        #navigatieExtra p{
            display: none;
        }

        footer{
            display: block;
        }
    }
</style>


