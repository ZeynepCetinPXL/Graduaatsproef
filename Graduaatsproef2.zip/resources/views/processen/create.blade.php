<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>sollicitatie</title>
    <link rel="stylesheet" href="{{ URL::asset('css/dashboardStyle.css') }}">
</head>

<body>

<header>
    <div id="logo">
        <img src="{{ URL::asset('assets/logo.svg')}}" width="100px" alt="logo">
    </div>
    <div>
        <h2 style="font-size: 2VW;">Wat is jouw motivatie om voor Krits te komen werken?</h2>
    </div>
    <div id="bob">
        <img src="{{ URL::asset('assets/bob.svg') }}" alt="bob">
    </div>
</header>

    <div class="popup">
        <div class="popupInfo">
            <div class="popupHead">
                <div>
                    <h1>Solliciteer</h1>
                </div>
            </div>
            <div>
                <form method="POST" action="/email/save">
                    @csrf
                    <label for="email">E-mailadres</label><br>
                    <input type="email" id="email" name="email" required><br>
                    @if(session('error'))
                        <p class="error">{{ session('error') }}</p>
                        <style> #email{border: 1px solid red}</style>
                    @endif
                    <button type="submit" class="knop">Verzenden</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>

<style>
    body{
        color: white;
        background-color: #272726;
    }

    header{
        height: 100px;
        display: flex;
        margin: 0 -5px;
        padding-top: 20px;
        align-items: center;
        justify-content: space-between;
    }

    #logo{
        margin-left: 50px;
    }

    #bob img{
        width: auto;
        height: 120px;
    }

    .popup{
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        margin: auto 0;
        position: absolute;
        text-align: center;
        align-items: center;
        justify-content: space-around;
    }

    .popupInfo{
        width: 50%;
        height: 290px;
        border-radius: 20px;
        background-color: #31342C;
    }

    .popupHead{
        display: flex;
        justify-content: space-around;
    }

    .popupHead div{
        width: 100%;
        margin: 20px;
        text-align: center;
    }

    #email{
        width: 200px;
        padding: 5px;
        color: #373934;
        border-radius: 5px;
        margin:  10px 40px 40px 40px;

    }

    .error{
        left: 0;
        right: 0;
        top: 53%;
        font-size: smaller;
        position: absolute;
    }

    .knop{
        cursor:pointer;
        border-radius: 12px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        padding: 10px 20px 10px 20px;
    }

    footer{
        width: 98%;
        bottom: 5px;
        text-align: center;
        position: absolute;
    }
</style>
