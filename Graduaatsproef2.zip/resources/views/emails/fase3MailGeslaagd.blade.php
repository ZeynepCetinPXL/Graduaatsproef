<html>
<body>
    <div class="emailText">
        <h3>Hallo daar!</h3>
        <p>
            Dank je voor de interesse in de positie van Designer.
        </p>
        <p>
            Wij en Bob zijn erg onder de indruk van jouw motivatie
            en zouden je graag wat beter willen leren kennen!
        <p>
            Als laatste stap in het sollicitatieproces willen we je vriendelijk vragen om een dag te kiezen uit onze agenda.
        </p>
        <p>
            We zouden graag wat meer over jou willen bijleren door je eens daadwerkelijk te ontmoeten!
        </p>
    </div>

    <div class="emailButton">
        <a href="https://workspace.google.com/intl/nl/products/calendar/" id="navLink">Plan een dag</a>
    </div>
</body>
</html>

<style>
    /*
    body{
        background-size:cover;
        background-repeat: no-repeat;
        background-image:url('http://graduaatsproef.test/assets/mailBB.png');
    }
     */

    .emailText{
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .emailButton{
        display: flex;
        margin-top: 30px;
        align-items: flex-start;
    }

    #navLink{
        color: white;
        font-weight: 600;
        padding: 10px 40px;
        border-radius: 10px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        text-decoration: none!important;
    }

</style>
