<html>
<body>
    <div class="emailText">
        <h3>Hallo sollicitant</h3>
        <p>
            Dank u voor uw interesse in de positie van Designer.
        </p>
        <p>
            Na een zorgvuldige evaluatie van alle ontvangen sollicitaties, moeten we u echter laten weten dat we op dit moment andere kandidaten hebben geselecteerd die beter aansluiten bij onze vereisten en behoeften.
        <p>
            We zijn dankbaar voor uw interesse in ons bedrijf en willen u bedanken voor uw tijd en moeite in het sollicitatieproces. We wensen u veel succes bij uw verdere carrière.    </p>
        <p>
            We hopen dat we u in de toekomst nog terug zien!
        </p>
    </div>
</body>
</html>

<style>
    .emailText{
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
</style>
