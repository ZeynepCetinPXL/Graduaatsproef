<html>
<body>
    <div class="emailText">
        <h3>Hallo daar!</h3>
        <p>
            Dank je voor de interesse in de positie van Designer.
        </p>
        <p>
            Als volgende stap in het sollicitatieproces willen we je vriendelijk vragen om een test in te vullen.
            Deze test is ontworpen om jouw vaardigheden en kennis te beoordelen en zal een belangrijk onderdeel zijn van onze evaluatie.        </p>
        <p>
            Voordat je begint, willen we je erop attenderen dat de test een tijdslimiet heeft.        </p>
        <p>
            Zodra u op onderstaande knop klikt, zal de timer starten.
        </p>
    </div>

    <div class="emailButton">
        <a href="http://sollicitatie.krits.be/test?id={{$gebruiker_id}}" id="navLink">Beginnen</a>
    </div>
</body>
</html>

<style>
    /*
    body{
        background-size:cover;
        background-repeat: no-repeat;
        background-image:url('http://graduaatsproef.test/assets/mailBB.png');
    }
     */

    .emailText{
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .emailButton{
        display: flex;
        margin-top: 30px;
        align-items: flex-start;
    }

    #navLink{
        color: white;
        font-weight: 600;
        padding: 10px 40px;
        border-radius: 10px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        text-decoration: none!important;
    }

</style>
