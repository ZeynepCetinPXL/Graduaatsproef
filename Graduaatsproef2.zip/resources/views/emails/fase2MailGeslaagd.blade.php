<html>
<body>
    <div class="emailText">
        <h3>Hallo daar!</h3>
        <p>
            Dank je voor de interesse in de positie van Designer.
        </p>
        <p>
            Wij en Bob zijn erg onder de indruk van de resultaten
            en zouden je graag wat beter willen leren kennen!
        <p>
            Als volgende stap in het sollicitatieproces willen we je vriendelijk vragen om een motivatie te geven over waarom je een onderdeel zou willen zijn van Krits.        <p>
            Zodra u op onderstaande knop klikt, zal de timer starten.
        </p>
        <p>
            De onderstaande knop is een form voor een motivatiebrief, laat ons weten wat je denkt!
        </p>
    </div>

    <div class="emailButton">
        <a href="http://sollicitatie.krits.be/motivatiebrief?id={{$gebruiker_id}}" id="navLink">Motivatiebrief</a>
    </div>
</body>
</html>

<style>
    /*
    body{
        background-size:cover;
        background-repeat: no-repeat;
        background-image:url('http://graduaatsproef.test/assets/mailBB.png');
    }
     */

    .emailText{
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .emailButton{
        display: flex;
        margin-top: 30px;
        align-items: flex-start;
    }

    #navLink{
        color: white;
        font-weight: 600;
        padding: 10px 40px;
        border-radius: 10px;
        border: 2px solid #E7FD52;
        background-color: #373934;
        text-decoration: none!important;
    }

</style>
