<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Motivatiebrief</title>
</head>
<body>
<header>
    <div id="logo">
        <img src="{{ URL::asset('assets/logo.svg')}}" width="100px" alt="logo">
    </div>
    <div>
        <h2 style="font-size: 2VW;"></h2>
    </div>
    <div id="bob">
        <img src="{{ URL::asset('assets/bob.svg') }}" alt="bob">
    </div>
</header>

    <div class="mid">
        <h1>
            Dank je voor je tijd. <br>
            Je motivatiebrief is verzonden naar Bob!
        </h1>
    </div>

    <footer>
        <p>Graduaatproef Zeynep Çetin</p>
    </footer>
</body>
</html>


<style>
    body{
        color: white;
        background-color: #272726;
    }

    header{
        height: 100px;
        display: flex;
        margin: 0 -5px;
        padding-top: 20px;
        align-items: center;
        justify-content: space-between;
    }

    #logo{
        margin-left: 50px;
    }

    #bob img{
        width: auto;
        height: 120px;
    }

    .mid{
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        margin: auto 0;
        position: absolute;
        text-align: center;
        align-items: center;
        justify-content: space-around;
    }


    footer{
        left: 0;
        right: 0;
        bottom: 0;
        color: grey;
        margin: 0 auto;
        position: fixed;
        text-align: center;
    }
</style>
