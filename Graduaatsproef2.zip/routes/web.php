<?php

use App\Http\Controllers\MotivatiebriefController;
use App\Http\Controllers\GebruikerController;
use App\Http\Controllers\ScoreController;
use Illuminate\Support\Facades\Route;
use App\Models\Gebruiker;

/* dashboards */
    Route::get('/dashboard', function () {
        $gebruikers = Gebruiker::all();
        return view('dashboards/dashboard_sollicitaties', ['gebruikers' => $gebruikers]);
    });

    /* vacatures database*/
    Route::get('/dashboard_vacatures', function () {
        $vacatures = App\Models\Vacature::all();
        return view('dashboards/dashboard_vacatures', compact('vacatures'));
    });

    /* testen database */
    Route::get('/dashboard_testen', function () {
        $testen = App\Models\Test::all();
        return view('dashboards/dashboard_testen', compact('testen'));
    });

/* begin van processen */
Route::get('/', function (){
   return view('processen/start');
});

/* email registratie & verzending automatische mail */
Route::get('/email', [GebruikerController::class, 'saveEmailPage']);
Route::post('/email/save', [GebruikerController::class, 'saveEmail']);

/* email test - processen 1*/
Route::get('/test', [ScoreController::class, 'saveScorePage']);
Route::post('/test/save', [ScoreController::class, 'saveScore']);
//redirect
Route::get('/test/end', function () {
    return view('controles/testEnd');
})->name('testEnd');


/* motivatiebrief - proces 2*/
Route::get('/motivatiebrief', [MotivatiebriefController::class, 'saveMotivatiePage']);
Route::post('/motivatiebrief/save', [MotivatiebriefController::class, 'saveMotivatie']);
//redirect
Route::get('/motivatiebrief/end', function () {
    return view('controles/motivatiebriefEnd');
})->name('motivatiebriefEnd');


/* motivatiebrief beoordelen - proces 3*/
Route::post('/motivatiebriefResultaat/save', [MotivatiebriefController::class, 'saveMotivatieResultaat']);
